// dllmain.h : Declaration of module class.

class CEAAddIn1Module : public ATL::CAtlDllModuleT< CEAAddIn1Module >
{
public :
	DECLARE_LIBID(LIBID_EAAddIn1Lib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_EAADDIN1, "{01E4BEE3-BB75-45F9-B512-F5BC1C788D6E}")
};

extern class CEAAddIn1Module _AtlModule;
