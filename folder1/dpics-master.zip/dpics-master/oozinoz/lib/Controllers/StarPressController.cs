using System;

namespace Controllers
{
	/// <summary>
	/// This class just supports examples in the Bridge chapter.
	/// It doesn't really control a star press.
	/// </summary>
	public class StarPressController
    {
        public void Start() {}
        public void Stop() {}
        public void StartProcess() {}
        public void EndProcess() {}
        public void Index() {}
        public void Discharge() {}
	}
}
