namespace Carousel
{
    /// <summary>
    /// A minimal delegate type, discussed in the "Observer" chapter.
    /// </summary>
    public delegate void ChangeHandler();
}
