using System;  

/// <summary>
/// Show an interface that uses properties.
/// </summary>
public interface IAdvertisement2
{
    int ID {get;}	
    string AdCopy { get; set; }
}
