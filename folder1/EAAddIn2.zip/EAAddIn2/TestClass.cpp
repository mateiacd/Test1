// TestClass.cpp : Implementation of CTestClass

#include "stdafx.h"
#include "TestClass.h"


// CTestClass



STDMETHODIMP CTestClass::EA_CONNECT(IDispatch* pRepository, BSTR* szReturn)
{
	// TODO: Add your implementation code here
	MessageBox(NULL, _T("EA_CONNECT from C++ add-in"), _T("EAAddIn1"), MB_OK);

	CString szTemp(_T("Connect from C++ add-in"));



	*szReturn = szTemp.AllocSysString();


	return S_OK;
}
