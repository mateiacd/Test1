// dllmain.h : Declaration of module class.

class CEAAddIn2Module : public ATL::CAtlDllModuleT< CEAAddIn2Module >
{
public :
	DECLARE_LIBID(LIBID_EAAddIn2Lib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_EAADDIN2, "{40950CE8-D3E8-4C39-B793-BCB4133C7FE1}")
};

extern class CEAAddIn2Module _AtlModule;
